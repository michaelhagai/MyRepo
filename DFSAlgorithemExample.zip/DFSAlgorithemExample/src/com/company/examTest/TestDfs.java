package com.company.examTest;

import com.company.exam.Graph;
import com.company.exam.Results;
import com.company.exam.StringChecker;

import static org.junit.Assert.assertEquals;

public class TestDfs {

    @org.junit.Test
    public void testChars() 
    {
        Graph graph = new Graph();
        for (int i = 0; i < 6; i++) {
            graph.addNode(i);
        }

        graph.addEdge(0, 4);
        graph.addEdge(0, 1);
        graph.addEdge(0, 5);
        graph.addEdge(1, 4);
        graph.addEdge(1, 3);
        graph.addEdge(2, 1);
        graph.addEdge(3, 4);
        graph.addEdge(3, 2);

        Results results = new Results();
        graph.dfs(0,2,results);

//        System.out.println(results.printPath());
        assertEquals("Should be Equal", "[0,1,3,2]", results.printPath());


    }
}
