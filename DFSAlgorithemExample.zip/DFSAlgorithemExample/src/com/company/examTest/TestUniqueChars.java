package com.company.examTest;

import com.company.exam.StringChecker;

import static org.junit.Assert.assertEquals;

public class TestUniqueChars {

    @org.junit.Test
    public void testChars() 
    {
        StringChecker stringChecker = new StringChecker();

        assertEquals("Should be True", true, stringChecker.uniqueChars(""));
        assertEquals("Should be False", false, stringChecker.uniqueChars("foo"));
        assertEquals("Should be True", true, stringChecker.uniqueChars("bar"));
    }
}
