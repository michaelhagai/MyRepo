package com.company.exam;

import java.util.HashSet;
import java.util.Set;

public class StringChecker 
{

    public boolean uniqueChars(String string)
    {
    	Set<String> uniqueChars = new HashSet<String>();
    	
    	char[] charArray = string.toCharArray();
    	
    	for (int i = 0; i < charArray.length; i++) 
    	{
    		uniqueChars.add(String.valueOf(charArray[i]));
		}
    	
		System.out.println(uniqueChars + " --> " + string);

    	if(uniqueChars.size() == charArray.length)
    	{
    		return true;
    	}
    	
        return false;
    }

}
