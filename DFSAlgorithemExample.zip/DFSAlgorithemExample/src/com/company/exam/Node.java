package com.company.exam;

import java.util.LinkedList;

public class Node {
    public int nodeId;
    public LinkedList<Node> adjacent;

    public Node(int nodeId) {
        adjacent = new LinkedList<>();
        this.nodeId = nodeId;
    }

    @Override
    public int hashCode() {
        return nodeId;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Node){
            return nodeId == ((Node)obj).nodeId;
        }
        return super.equals(obj);
    }

    @Override
    public String toString() {
        return String.valueOf(nodeId);
    }
}
