package com.company.exam;


import java.awt.peer.SystemTrayPeer;
import java.util.*;

public class Graph 
{
	private Map<Integer,Node> nodes = new HashMap<>();
	private	List<Node> reversedPathList = new ArrayList<Node>();


	public void addNode(int nodeId){
		nodes.put(nodeId,new Node(nodeId));
	}

	private Node getNode(int nodeId) {
		return nodes.get(nodeId);
	}

	public void addEdge(int source,int destination){
		Node dest = nodes.get(destination);
		nodes.get(source).adjacent.add(dest);
	}

	//My Implementation
	public void dfs(int source,int destination,Results results)
	{
		Node start = nodes.get(source);
		Node end = nodes.get(destination);
		Set<Node> visitedNodes = new HashSet<Node>();
		LinkedList<Node> adjacentNodes = start.adjacent;

//		System.out.println(start);
		for (Iterator<Node> iterator = adjacentNodes.iterator(); iterator.hasNext();) 
		{
			Node adjacentNode = (Node) iterator.next();
			if(!visitedNodes.contains(adjacentNode))
			{
				if(end.equals(adjacentNode))
				{
					reversedPathList.add(end);
//					System.out.println(end);
				}
				else
				{
					if(adjacentNode!=null && !visitedNodes.contains(adjacentNode))
					{
						dfs(adjacentNode.nodeId, destination, results);
						visitedNodes.add(adjacentNode);
					}
				}	

				if(reversedPathList.size()>0 && !reversedPathList.contains(start))
				{
					reversedPathList.add(start);
				}
			}
		}

		updateResult(results);
		System.out.println(results.pathList);
	}

	private void updateResult(Results results) 
	{
		results.pathList.clear();
		for (int i = reversedPathList.size() -1 ; i>=0 ; i--) 
		{
			results.pathList.add(reversedPathList.get(i));
		}
	}

}
