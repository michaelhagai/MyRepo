package com.company.exam;


import java.util.ArrayList;
import java.util.List;

public class Results 
{
    public List<Node> pathList = new ArrayList<>();

    public String printPath() 
    {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < pathList.size(); i++) {
            sb.append(pathList.get(i));
            if (pathList.size()-1 != i){
                sb.append(",");
            }
        }

        sb.append("]");
        return sb.toString();
    }

}
