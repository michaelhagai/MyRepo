package com.fms.storage;

import static com.fms.constants.ExceptionsConstants.*;
import static com.fms.constants.AppConstants.*;

import java.util.*;

import org.springframework.stereotype.Component;

import com.fms.exceptions.FMSException;
import com.fms.storeditemsbeans.*;

/**
 * 
 * @author MHAGAI
 *	This Class represents the data Structure that keeps all items and their relations.
 *	Contains:
 *	1. Map with all Items instances.
 *	2. Items relations to parent directory
 *	3. "root" directory
 */
@Component
public class SystemStorage
{
	private Map<String, ManagedItem> itemsMap;
	private Map<String, String> itemToParentDirectoryMap;
	private Directory root;

	public SystemStorage() throws FMSException
	{
		itemsMap = new HashMap<String, ManagedItem>();
		itemToParentDirectoryMap = new HashMap<String, String>();
		root = new Directory(ROOT_DIRECTORY);

		itemsMap.put(ROOT_DIRECTORY, root);
	}

	public void addItem(ManagedItem item) throws FMSException
	{
		if(!isNameExist(item.getName()) && item != null)
		{
			itemsMap.put(item.getName(), item);
		}
		else
		{
			throw new FMSException(String.format(ERROR_NAME_NOT_UNIQUE, item.getName()));
		}
	}

	public void removeItem(String name) throws FMSException
	{
		if(isNameExist(name))
		{
			itemsMap.remove(name);
			itemToParentDirectoryMap.remove(name);
		}
	}

	public void linkItemToParentDirectory(String itemName, String parentDirectoryName) throws FMSException
	{
		if(isNameExist(itemName) && isNameExist(parentDirectoryName))
		{
			itemToParentDirectoryMap.put(itemName, parentDirectoryName);
		}
		else
		{
			throw new FMSException(ERROR_NAME_IS_NULL);
		}
	}

	public ManagedItem getItem(String name)
	{
		return itemsMap.get(name);
	}

	public Directory getParentDirectory(String name)
	{
		String parentDirectoryName = itemToParentDirectoryMap.get(name);
		ManagedItem parentDirectory = parentDirectoryName !=null ? itemsMap.get(parentDirectoryName) : null;

		return (Directory) parentDirectory;
	}

	public boolean isNameExist(String name)
	{
		if(itemsMap.containsKey(name))
		{
			return true;
		}
		return false;
	}

	public boolean isFile(String name)
	{
		if(itemsMap.containsKey(name) && itemsMap.get(name) instanceof File)
		{
			return true;
		}
		return false;
	}

	public boolean isDirectory(String name)
	{
		if(itemsMap.containsKey(name) && itemsMap.get(name) instanceof Directory)
		{
			return true;
		}
		return false;
	}

	public void displaySystemStorage(ManagedItem item, int numOfSpaces)
	{
		int n = numOfSpaces;
		char[] spaces = new char[n];
		Arrays.fill(spaces, ' ');
		
		if(isFile(item.getName()))
		{
			System.out.println(new String(spaces) + item);
		}
		
		if(isDirectory(item.getName()))
		{
			System.out.println(new String(spaces) + item);
			Set<String> relatedItems = ((Directory)item).getAllRelatedItems();
			for(String relatedItemName : relatedItems)
			{
				displaySystemStorage(getItem(relatedItemName),n+1);
			}
		}
	}

	public Directory getRoot()
	{
		return root;
	}

}
