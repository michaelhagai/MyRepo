package com.fms.constants;

public class AppConstants 
{
	public final static long NAME_MAX_SIZE = 32;
	public final static String ITEM_TYPE_DIRECTORY= "directory";
	public final static String ITEM_TYPE_FILE= "file";
	
	public final static String ROOT_DIRECTORY= "root";

}
