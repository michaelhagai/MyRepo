package com.fms.constants;

public class ExceptionsConstants
{
	public final static String  ERROR_NAME_IS_NULL = "ERROR: Name value cannot be null";
	public final static String  ERROR_NAME_NOT_UNIQUE = "ERROR: Name: %s already exists in the system";
	public final static String  ERROR_PARANET_DIRECTORY_NOT_EXIST = "ERROR: Directory Name: %s does not exist in the system";
	public final static String  ERROR_NAME_MAX_SIZE = "ERROR: Valid name length should be up to 32 characters. Name: %s , Length: %s";
	public final static String  ERROR_SIZE_MIN_VALUE = "ERROR: File Size must be positive long int. FileName: %s , Size: %s";
	public final static String  ERROR_ITEM_TYPE_MISMATCH= "ERROR: Item name: %s is not %s";

} 
