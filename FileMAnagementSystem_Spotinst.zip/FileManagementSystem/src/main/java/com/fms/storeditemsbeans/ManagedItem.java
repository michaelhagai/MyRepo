package com.fms.storeditemsbeans;

import java.util.Date;

import static com.fms.constants.ExceptionsConstants.*;
import static com.fms.constants.AppConstants.*;

import com.fms.exceptions.FMSException;

/**
 * 
 * @author MHAGAI
 * This Abstract class represents a managed item in the file system..  
 * Includes basic parameters and validations: name, creationDate.
 */
public abstract class ManagedItem
{
	private String name;
	private Date creationDate;
	
	public ManagedItem(String name) throws FMSException 
	{
		nameValidation(name);
		this.name = name;
		this.creationDate = new Date();
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Date getCreationDate()
	{
		return creationDate;
	}
	
	/**
	 * Validations:
	 * 1. Name must have value.
	 * 2. Name length should be up to AppConstants.NAME_MAX_SIZE chars
	 * 
	 * @throws FMSException
	 */
	private void nameValidation(String name) throws FMSException
	{
		if(name == null)
		{
			throw new FMSException(ERROR_NAME_IS_NULL);
		}
		
		if(name.toCharArray().length > NAME_MAX_SIZE)
		{
			throw new FMSException(String.format(ERROR_NAME_MAX_SIZE, name, name.length()));
		}
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ManagedItem other = (ManagedItem) obj;
		if (name == null)
		{
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
}
