package com.fms.storeditemsbeans;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fms.exceptions.FMSException;
import com.fms.storage.SystemStorage;


/**
 * 
 * @author MHAGAI
 * This POJO extends ManagedItem and representing a Directory object.  
 * Includes SET with all related Items names. when needed they will be taken from SystemStorage by name.
 */
@Component
@Scope("prototype")
public class Directory extends ManagedItem
{
	@Autowired
	SystemStorage itemStorage;
	private Set<String> storedItemsNames;

	public Directory(String name) throws FMSException
	{
		super(name);
		storedItemsNames = new HashSet<String>();
	}

	public void addItemToDirectory(String name)
	{
		storedItemsNames.add(name);
	}
	
	public boolean removeItemFromDirectory(String name)
	{
		return storedItemsNames.remove(name);
	}

	@SuppressWarnings("unchecked")
	public Set<String> getAllRelatedItems()
	{
		return (Set<String>) ((HashSet<String>)storedItemsNames).clone();
	}
	
	@Override
	public String toString()
	{
		return "Directory [Name=" + getName()+ ", CreationDate="+ getCreationDate()+", storedItemsNames=" + storedItemsNames +"]";
	}
	
}
