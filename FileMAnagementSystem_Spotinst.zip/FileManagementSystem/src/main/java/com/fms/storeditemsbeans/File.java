package com.fms.storeditemsbeans;

import static com.fms.constants.ExceptionsConstants.*;

import java.util.Calendar;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fms.exceptions.FMSException;

/**
 * 
 * @author MHAGAI
 * This POJO extends ManagedItem and representing a File object.  
 * 
 */
@Component
@Scope("prototype")
public class File extends ManagedItem
{

	private long size;

	public File(String name, long size) throws FMSException
	{
		super(name);
		validateSize(size);
		this.size = size;
	}

	/**
	 * Validations:
	 * 1.File size is a positive long int.
	 * 
	 * @param size
	 * @throws FMSException
	 */
	private void validateSize(long size) throws FMSException
	{
		if(size < 1)
		{
			throw new FMSException(String.format(ERROR_SIZE_MIN_VALUE, super.getName(),size));
		}
	}

	public long getSize()
	{
		return size;
	}

	public void setSize(long size)
	{
		this.size = size;
	}

	@Override
	public String toString()
	{
		return String.format("File [Name= %s, size=%s, CreationDate=%s]",getName(), size, getCreationDate());
	}
		
}
