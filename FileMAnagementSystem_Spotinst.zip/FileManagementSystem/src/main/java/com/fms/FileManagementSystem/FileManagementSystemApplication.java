package com.fms.FileManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

import com.fms.exceptions.FMSException;
import com.fms.managers.SystemManager;
import com.fms.storeditemsbeans.Directory;
import com.fms.storeditemsbeans.File;
import com.fms.storeditemsbeans.ManagedItem;

@SpringBootApplication
@ComponentScan(basePackages = {"com.fms"})
@PropertySource("application.properties")
public class FileManagementSystemApplication
{
	public static void main(String[] args) throws FMSException
	{
		ApplicationContext ctx = SpringApplication.run(FileManagementSystemApplication.class, args);
		
		SystemManager sysManager = (SystemManager) ctx.getBean("systemManager");
		
		
		sysManager.addDir(null, "Program Files");
		sysManager.addDir("Program Files","Java" );
		sysManager.addDir("Program Files","Office" );
		sysManager.addDir("Office", "Word");
		sysManager.addDir("Office", "Excel");
		//sysManager.addDir("Office", "Exllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllcel");// Remove comment to see Name length exception
		sysManager.addDir("Office", "PowerPoint");
		sysManager.addDir("Office", "Visio");

		sysManager.addDir("Word", "sysFiles");
		sysManager.addFile("Word", "Word.exe", 2);
		//sysManager.addFile("Word", "Word.exe", -1); // Remove comment to see fileSize exception
		sysManager.addFile("Word", "WordREADME.txt", 2);
		sysManager.addFile("Excel", "Excel.exe", 2);
		sysManager.addFile("Excel", "ExcelREADME.txt", 1);
		sysManager.addFile("PowerPoint", "PowerPoint.exe", 2);
		sysManager.addFile("PowerPoint", "PowerPointREADME.txt", 1);
		sysManager.addFile("Visio", "Visio.exe", 2);
		sysManager.addFile("Visio", "VisioREADME.txt", 1);
		
		sysManager.showFileSystem();
		
		sysManager.delete("Word.exe");
		sysManager.showFileSystem();
		
		sysManager.delete("Office");
		sysManager.showFileSystem();

		
	}
}
