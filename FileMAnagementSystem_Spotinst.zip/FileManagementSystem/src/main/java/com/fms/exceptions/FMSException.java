package com.fms.exceptions;

public class FMSException extends Exception 
{
	private static final long serialVersionUID = 1L;
	private int errcode;

	public int getErrcode() 
	{
		return errcode;
	}

	public void setErrcode(int errcode) 
	{
		this.errcode = errcode;
	}

	public FMSException(String message, Throwable cause) 
	{
		super(message, cause);
	}

	public FMSException(String message) 
	{
		super(message);
	}

	public FMSException(String message, int errcode) 
	{
		super(message);
		this.setErrcode(errcode);
	}
	
}
