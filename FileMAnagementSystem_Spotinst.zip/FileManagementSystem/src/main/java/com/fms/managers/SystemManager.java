package com.fms.managers;

import static com.fms.constants.ExceptionsConstants.*;
import static com.fms.constants.AppConstants.*;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.fms.exceptions.FMSException;
import com.fms.storage.SystemStorage;
import com.fms.storeditemsbeans.*;

/**
 * 
 * @author MHAGAI
 * This Class Manages the file System: 
 * 	1. Creating Items and Storing them in SystemStorage.
 * 	2. Deleting Items from SystemStorage.
 * 	3. Displaying all File System Data
 */
@Component
public class SystemManager 
{
	@Autowired
	ApplicationContext context;
	@Autowired
	private SystemStorage itemStorage;

	public void addFile(String parentDirName, String fileName, int fileSize) throws FMSException
	{
		if(parentDirName != null && fileName != null)
		{
			ManagedItem file = createFileInstance(fileName, fileSize);	
			addItemToParentDirectory(parentDirName, file);
		}
		else
		{
			throw new FMSException(ERROR_NAME_IS_NULL);
		}
	}

	/**
	 * 
	 * @param parentDirName - if null? relate to root directory
	 * @param dirName
	 * @throws FMSException
	 */
	public void addDir(String parentDirName, String dirName) throws FMSException
	{
		if(dirName != null)
		{
			validateParentDirectoryName(parentDirName);
			ManagedItem dir = createDirectoryInstance(dirName);
			String newParentDirName = parentDirName == null? ROOT_DIRECTORY : parentDirName;
			addItemToParentDirectory(newParentDirName, dir);

		}
		else
		{
			throw new FMSException(ERROR_NAME_IS_NULL);
		}


	}

	/**
	 * This Method Deletes the Directory or the File of a given name.
	 * If Directory is being deleted - all Related Items will be deleted as well Recursively
	 * 
	 * @param name
	 * @throws FMSException
	 */
	public void delete(String name) throws FMSException
	{
		ManagedItem itemToRemove = itemStorage.getItem(name);

		if(itemToRemove != null)
		{
			if(itemStorage.isDirectory(name))
			{
				Set<String> relatedItems =  ((Directory) itemToRemove).getAllRelatedItems();

				for (String relatedItemName : relatedItems)
				{
					delete(relatedItemName);
				}
			}

			Directory parentDirectory = itemStorage.getParentDirectory(name);
			parentDirectory.removeItemFromDirectory(name);
			itemStorage.removeItem(name);
		}
	}

	/**
	 * Recursively displaying all files and directory. 
	 * Start point - "root" Directory
	 */
	public void showFileSystem ()
	{
		System.out.println("************************************************************************************************************************************************************");
		System.out.println("File System Details:");
		System.out.println("--------------------");
		itemStorage.displaySystemStorage(itemStorage.getItem(ROOT_DIRECTORY),0);
		System.out.println("************************************************************************************************************************************************************");

	}

	private void addItemToStorage(ManagedItem item) throws FMSException
	{
		if(!itemStorage.isNameExist(item.getName()))
		{	
			itemStorage.addItem(item);
		}
		else
		{
			throw new FMSException(String.format(ERROR_NAME_NOT_UNIQUE, item.getName()));
		}
	}

	private void addItemToParentDirectory(String parentDirName,ManagedItem item) throws FMSException
	{
		if(itemStorage.isNameExist(parentDirName))
		{
			if(itemStorage.isDirectory(parentDirName))
			{
				ManagedItem parentDirectory = itemStorage.getItem(parentDirName);

				relateItemToParentDirectory(item, (Directory)parentDirectory);
			}
			else
			{
				itemStorage.removeItem(item.getName());
				throw new FMSException(String.format(ERROR_ITEM_TYPE_MISMATCH, parentDirName , ITEM_TYPE_DIRECTORY));

			}
		}
		else
		{
			throw new FMSException(String.format(ERROR_PARANET_DIRECTORY_NOT_EXIST, parentDirName));
		}
	}

	/*
	 * 1. Update item name in Directory object
	 * 2. update SystemStorage about this link 
	 */
	private void relateItemToParentDirectory(ManagedItem item, Directory parentDirectory) throws FMSException
	{
		parentDirectory.addItemToDirectory(item.getName());
		itemStorage.linkItemToParentDirectory(item.getName(), parentDirectory.getName());
	}

	private ManagedItem createDirectoryInstance(String name) throws FMSException
	{
		ManagedItem dir = (ManagedItem) context.getBean(ITEM_TYPE_DIRECTORY, name);
		addItemToStorage(dir);
		return dir;
	}

	private ManagedItem createFileInstance(String name, int fileSize) throws FMSException
	{
		ManagedItem file = (ManagedItem) context.getBean(ITEM_TYPE_FILE, name, fileSize);
		addItemToStorage(file);
		return file;
	}
	
	private void validateParentDirectoryName(String parentDirName)
			throws FMSException
	{
		if(parentDirName != null)
		{
			if(parentDirName.equalsIgnoreCase(ROOT_DIRECTORY))
			{
				throw new FMSException(String.format(ERROR_NAME_NOT_UNIQUE,ROOT_DIRECTORY));
			}
		}
	}

}
