package com.example;

public class ExpirationThread extends Thread
{
	private MyDataStructure dataStructure;
	private String key;
	private Object value;
	private int timeToLive;


	public ExpirationThread(String key, Object value, int timeToLive , MyDataStructure dataStructure)
	{
		this.dataStructure = dataStructure;
		this.key = key;
		this.value = value;
		this.timeToLive = timeToLive;
	}

	@Override
	public void run() 
	{
		try 
		{
			sleep(timeToLive);
			dataStructure.remove(key);
		} 
		catch (InterruptedException e) 
		{
			e.printStackTrace();//only for example
		}
	}
}
