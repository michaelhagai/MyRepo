package com.example;

import java.util.*;

/**
 * 
 * @author MHAGAI
 *	This Data structure contains HashMap with values that stored also in MyDoublyLinkedList object in order to run operations in O(1) complexity.
 *	Currently it does not supporting multithreading as it was notpart of the requirements. this functionality can be done easily by synchronizing the operations.
 *	By adding new data to the beginning of the linkedList the oldest data will be at the tail of the linkedList and it can be identified and remove easily.
 *	Each data with expiration time > 0 will be added into a new thread that is waiting for expiration time before removing it from the data structure.
 *	Removing data from the middle of linkedList is in o(1) as it's being identified from the Hashmap.     
 */
public class MyDataStructure 
{
	private final int maxCapacity;
	private MyDoublyLinkedList<String, String> myList;
	private Map<String, MyNode<String, String>> myMap;
	private final static Object MUTEX = new Object(); 

	public MyDataStructure(int capacity) 
	{
		this.maxCapacity = capacity;
		this.myList = new MyDoublyLinkedList<String, String>();
		this.myMap = new HashMap<String, MyNode<String,String>>();
	}

	/**
	 * add value to the data structure. complexity is o(1)
	 * @param key
	 * @param value
	 * @param timeToLive
	 */
	public void put(String key, Object value, int timeToLive) 
	{	
		if(key != null)
		{

			if(dataStructureIsFull())
			{
				removeOldestNode();
			}

			if(keyExistsInMap(key))
			{
				myMap.get(key).setValue((String) value);
			}
			else
			{
				addNewNode(key, value, timeToLive);

				if (timeToLive > 0) 
				{
					runExpirationThread(key, value, timeToLive);
				}
			}		
		}
	}

	/**
	 * remove value from the data structure. complexity is o(1)
	 * @param key
	 */
	public void remove(String key) 
	{
		if(key != null)
		{
			MyNode<String, String> node = myMap.remove(key);
			myList.remove(node);
		}
	}

	/**
	 * get value from the data structure. complexity is o(1)
	 * @param key
	 * @return
	 */
	public Object get(String key) 
	{
		if(myMap.get(key) == null)
		{
			return null;
		}

		return myMap.get(key).getValue();
	}

	/**
	 * get number of keys in the data structure. complexity is o(1)
	 * @return number of keys in the data structure
	 */
	public int size() 
	{
		return myMap.size();
	}

	private void runExpirationThread(String key, Object value, int timeToLive) 
	{
		ExpirationThread expirationThread = new ExpirationThread(key, value, timeToLive, this);
		expirationThread.start();
	}

	private void addNewNode(String key, Object value, int timeToLive) 
	{
		MyNode<String, String> node = new MyNode<String, String>(key, (String) value, timeToLive);
		myMap.put(key, node);
		myList.addFirst(node);
	}

	private MyNode<String, String> removeOldestNode() 
	{
		MyNode<String, String> oldestNode = myList.getLast();
		remove(oldestNode.getKey());
		return oldestNode;
	}

	private boolean keyExistsInMap(String key) 
	{
		return myMap.get(key) != null;
	}

	private boolean dataStructureIsFull() 
	{
		return myMap.size() == maxCapacity;
	}

}
