package com.example;

public class MyNode<K,V>
{
	private MyNode<K,V> previous;
	private MyNode<K,V> next;
	private V value;
	private final K key;
	private int timeToLive;

	public MyNode(K key, V value, int timeToLive)
	{
		this.key = key;
		this.value = value;
		this.timeToLive = timeToLive;
	}

	public K getKey() 
	{
		return key;
	}

	public V getValue() 
	{
		return value;
	}

	public void setValue(V value) 
	{
		this.value = value;
	}

	public MyNode<K,V> getPrevious() 
	{
		return previous;
	}

	public void setPrevious(MyNode<K, V> prev) 
	{
		this.previous = prev;
	}

	public MyNode<K,V> getNext() 
	{
		return next;
	}

	public void setNext(MyNode<K,V> next) 
	{
		this.next = next;
	}

	public int getTimeToLive() 
	{
		return timeToLive;
	}

	public void setTimeToLive(int timeToLive) 
	{
		this.timeToLive = timeToLive;
	}

	@Override
	public String toString() 
	{
		String previousKey = (String) (previous==null? null : previous.getKey());
		String nextKey = (String) (next==null? null : next.getKey());

		return String.format("MyNode [previous= %s ,next= %s ,value= %s ,key= %s ,timeToLive= %s]", previousKey, nextKey,value ,key, timeToLive );
	}
}
