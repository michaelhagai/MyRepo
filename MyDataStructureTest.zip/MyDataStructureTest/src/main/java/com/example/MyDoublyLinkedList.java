package com.example;

import com.example.MyNode;

class MyDoublyLinkedList<K, V>
{
	private MyNode<K, V> head;
	private MyNode<K, V> tail;

	public MyDoublyLinkedList(){}

	public void addFirst(MyNode<K, V> node) 
	{
		if(node != null)
		{
			if(head != null)
			{
				node.setNext(head);
				head.setPrevious(node);
			}

			head = node;

			if (tail == null)
			{
				tail = node;
			}
		}
	}

	public void addLast(MyNode<K, V> node) 
	{
		if(node != null)
		{
			if(tail != null)
			{
				node.setPrevious(tail);
				tail.setNext(node);
			}

			tail = node;

			if (head == null)
			{
				head = node;
			}
		}
	}

	public MyNode<K, V> getFirst() 
	{
		return head;
	}
	
	public MyNode<K, V> getLast()
	{
		return tail;
	}

	public void remove(MyNode<K, V> node) 
	{
		if(node != null)
		{
			if(node == head)
			{
				updateHead(node);
			}
			else if (node == tail) 
			{
				updateTail(node);
			}
			else
			{
				removeNode(node);
			}
		}
	}

	private void removeNode(MyNode<K, V> node) 
	{
		node.getPrevious().setNext(node.getNext());
		node.getNext().setPrevious(node.getPrevious());
		node.setNext(null);
		node.setPrevious(null);
	}

	private void updateTail(MyNode<K, V> node) 
	{
		tail = node.getPrevious();
		tail.setNext(null);
		node.setPrevious(null);
	}

	private void updateHead(MyNode<K, V> node) 
	{
		head = node.getNext();
		head.setPrevious(null);
		node.setNext(null);
	}
}
