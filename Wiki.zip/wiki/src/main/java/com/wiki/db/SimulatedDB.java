package com.wiki.db;

import org.springframework.stereotype.Component;

import com.wiki.beans.*;
import java.util.*;

/**
 * This class simulates WIKI_DB Schema.
 * 
 * @author MHAGAI
 *
 */

@Component
public class SimulatedDB 
{
	private Map<Long,Page> pagesTable;
	private Map<Long,Paragraph> paragraphTable;
	private Map<Long,Picture> pictureTable;
	private Map<Long,Map<Long,Picture>> page2PictureRelations;
	private Map<Long,Map<Long,Page>> picture2PageRelations;
	private Map<Long,Map<Long,Page>> page2PageRelations;
	private Map<Long, Map<Long, Page>> paragraph2PageRelations;
	private Map<Long, Map<Long, Paragraph>> page2ParagraphRelations;

	public SimulatedDB() 
	{
		pagesTable = new HashMap<Long, Page>();
		paragraphTable = new HashMap<Long, Paragraph>();
		pictureTable = new HashMap<Long, Picture>();
		page2PictureRelations = new HashMap<Long, Map<Long,Picture>>();
		picture2PageRelations = new HashMap<Long, Map<Long,Page>>();
		page2PageRelations = new HashMap<Long, Map<Long,Page>>();
		paragraph2PageRelations = new HashMap<Long, Map<Long,Page>>();
		page2ParagraphRelations = new HashMap<Long, Map<Long,Paragraph>>();
		initilizeDummyData();
	}


	public Map<Long, Page> getPagesTable() 
	{
		return pagesTable;
	}

	public Map<Long, Paragraph> getParagraphTable() {
		return paragraphTable;
	}

	public Map<Long, Picture> getPictureTable() {
		return pictureTable;
	}

	public Map<Long, Map<Long, Picture>> getPage2PictureRelations() {
		return page2PictureRelations;
	}

	public Map<Long, Map<Long, Page>> getPicture2PageRelations() {
		return picture2PageRelations;
	}

	public Map<Long, Map<Long, Page>> getPage2PageRelations() {
		return page2PageRelations;
	}

	public Map<Long, Map<Long, Page>> getParagraph2PageRelations() {
		return paragraph2PageRelations;
	}

	public Map<Long, Map<Long, Paragraph>> getPage2ParagraphRelations() {
		return page2ParagraphRelations;
	}
		
	public long setIdCounter(long idCounter) 
	{
		return idCounter;
	}
		
	private void initilizeDummyData() 
	{
		Page page1 = new Page(1, "pizzaPage", "Michael The Pizza");
		Page page2 = new Page(2, "burgerPage", "Michael The Burger");
		pagesTable.put(page1.getPageId(), page1);
		pagesTable.put(page2.getPageId(), page2);

		Paragraph paragraph1 = new Paragraph(1000, 1, "I love Pizza", 6);
		Paragraph paragraph2 = new Paragraph(1001, 2, "I love pineapple Pizza", 6);
		Paragraph paragraph3 = new Paragraph(1002, 3, "I love Pizza Hut with pineapple", 6);
		paragraphTable.put(paragraph1.getPararaphId(), paragraph1);
		paragraphTable.put(paragraph2.getPararaphId(), paragraph2);
		paragraphTable.put(paragraph3.getPararaphId(), paragraph3);

		Picture picture1 = new Picture(2000,"/pizza/hut/pic1.jpg", 2.2);
		Picture picture2 = new Picture(2001,"/pizza/hut/pic2.jpg", 3.3);
		Picture picture3 = new Picture(2002,"/pizza/hut/pic3.jpg", 4.4);
		pictureTable.put(picture1.getPictureId(), picture1);
		pictureTable.put(picture2.getPictureId(), picture2);
		pictureTable.put(picture3.getPictureId(), picture3);

		//PagePicture Relations
		page2PictureRelations.put(page1.getPageId(), new HashMap<Long,Picture>());
		page2PictureRelations.get(page1.getPageId()).put(picture1.getPictureId(), picture1);
		page2PictureRelations.get(page1.getPageId()).put(picture2.getPictureId(), picture2);
		page2PictureRelations.get(page1.getPageId()).put(picture3.getPictureId(), picture3);

		picture2PageRelations.put(picture1.getPictureId(), new HashMap<Long,Page>());
		picture2PageRelations.put(picture2.getPictureId(), new HashMap<Long,Page>());
		picture2PageRelations.put(picture3.getPictureId(), new HashMap<Long,Page>());
		picture2PageRelations.get(picture1.getPictureId()).put(page1.getPageId(), page1);
		picture2PageRelations.get(picture1.getPictureId()).put(page1.getPageId(), page1);
		picture2PageRelations.get(picture1.getPictureId()).put(page1.getPageId(), page1);

		//PageParagraph Relations
		page2ParagraphRelations.put(page1.getPageId(), new HashMap<Long,Paragraph>());
		page2ParagraphRelations.get(page1.getPageId()).put(paragraph1.getPararaphId(), paragraph1);
		page2ParagraphRelations.get(page1.getPageId()).put(paragraph2.getPararaphId(), paragraph2);
		page2ParagraphRelations.get(page1.getPageId()).put(paragraph3.getPararaphId(), paragraph3);

		paragraph2PageRelations.put(paragraph1.getPararaphId(), new HashMap<Long,Page>());
		paragraph2PageRelations.put(paragraph2.getPararaphId(), new HashMap<Long,Page>());
		paragraph2PageRelations.put(paragraph3.getPararaphId(), new HashMap<Long,Page>());
		paragraph2PageRelations.get(paragraph1.getPararaphId()).put(page1.getPageId(), page1);
		paragraph2PageRelations.get(paragraph2.getPararaphId()).put(page1.getPageId(), page1);
		paragraph2PageRelations.get(paragraph3.getPararaphId()).put(page1.getPageId(), page1);

		//PagePage Relations
		page2PageRelations.put(page1.getPageId(), new HashMap<Long,Page>());
		page2PageRelations.get(page1.getPageId()).put(page2.getPageId(), page2);

		page2PageRelations.put(page2.getPageId(), new HashMap<Long,Page>());
		page2PageRelations.get(page2.getPageId()).put(page1.getPageId(), page1);		
	}

}
