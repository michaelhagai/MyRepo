package com.wiki.dao;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wiki.beans.*;
import com.wiki.db.SimulatedDB;
import com.wiki.exception.ExceptionConstants;
import com.wiki.exception.WikiException;

/**
 * This Class represents the DB Calls for Page object
 * @author MHAGAI
 *
 */
@Component
public class PageDao 
{
	@Autowired
	private SimulatedDB db;

	public Page getPage(long pageId) throws WikiException
	{
		validatePage(pageId, ExceptionConstants.EXCEPTION_PAGE_NOT_EXIST);
		Page page = db.getPagesTable().get(pageId);
		Set<Long> relatedPagesId = db.getPage2PageRelations().get(pageId).keySet();
		Map<Long, Paragraph> relatedParagraphs = db.getPage2ParagraphRelations().get(pageId);
		Map<Long, Picture> relatedPictures = db.getPage2PictureRelations().get(pageId);

		page.setRelatedPagesId(relatedPagesId);
		page.setRelatedParagraph(relatedParagraphs);
		page.setRelatedPictures(relatedPictures);
		
		return page;
	}
	
	public void addNewPage(Page page) throws WikiException
	{
		ValidatePage(page);
		addPageIntoPagesTable(page);
		addRelatedPictures(page);
		addRelatedParagraphs(page);
		addRelatedPages(page);	
	}

	private void addRelatedParagraphs(Page page) throws WikiException 
	{
		Map<Long, Paragraph> relatedParagraphsMap = page.getRelatedParagraph();
		long pageId = page.getPageId();
		
		validatePage(pageId,ExceptionConstants.EXCEPTION_PAGE_NOT_EXIST_FAIL_TO_RELATE_PARAGRAPH);
		
		for(Map.Entry<Long, Paragraph> paragraphEntry : relatedParagraphsMap.entrySet())
		{
			Paragraph relatedParagraph = paragraphEntry.getValue();
			relatePageToParagraph(page, relatedParagraph);
		}
	}
	
	private void addRelatedPages(Page page) throws WikiException 
	{
		Set<Long> relatedPagesSet = page.getRelatedPagesId();
		long pageId = page.getPageId();
		
		validatePage(pageId,ExceptionConstants.EXCEPTION_PAGE_NOT_EXIST_FAIL_TO_RELATE_PARAGRAPH);
		if(relatedPagesSet!=null)
		{
			for(Long relatedPageId : relatedPagesSet)
			{
				Page relatedPage = db.getPagesTable().get(relatedPageId);
				if(relatedPage!=null)
				{
					relatePageToPage(page, relatedPage);
				}
				else
				{
					throw new WikiException(String.format(ExceptionConstants.EXCEPTION_PAGE_RELATION_NOT_EXIST,relatedPageId));
				}
			}
		}
	}

	private void addRelatedPictures(Page page) throws WikiException 
	{
		Map<Long, Picture> relatedPictures = page.getRelatedPictures();
		long pageId = page.getPageId();
		
		validatePage(pageId,ExceptionConstants.EXCEPTION_PAGE_NOT_EXIST_FAIL_TO_RELATE_PICTURES);
		
		for(Map.Entry<Long, Picture> pictureEntry : relatedPictures.entrySet())
		{
			Picture picture = pictureEntry.getValue();
			relatePageToPicture(page, picture);
		}
	}
	
	public Map<Long, Picture> getRelatedPictures(Page page) throws WikiException 
	{
		long pageId = page.getPageId();
		
		validatePage(pageId,ExceptionConstants.EXCEPTION_PAGE_NOT_EXIST);
		return db.getPage2PictureRelations().get(pageId);
	}
	
	public Map<Long, Paragraph> getRelatedParagraphs(Page page) throws WikiException 
	{
		long pageId = page.getPageId();
		
		validatePage(pageId,ExceptionConstants.EXCEPTION_PAGE_NOT_EXIST);
		return db.getPage2ParagraphRelations().get(pageId);
	}
	
	public Map<Long, Page> getRelatedPages(Page page) throws WikiException 
	{
		long pageId = page.getPageId();
		
		validatePage(pageId,ExceptionConstants.EXCEPTION_PAGE_NOT_EXIST);
		return db.getPage2PageRelations().get(pageId);
	}

	private void validatePage(long pageId,String validationExceptionDescription) throws WikiException 
	{
		if(db.getPagesTable().get(pageId)==null)
		{
			throw new WikiException(String.format(validationExceptionDescription, pageId));
		}	
	}

	private void addPageIntoPagesTable(Page page) throws WikiException 
	{
		long pageId = page.getPageId();

		if(db.getPagesTable().get(pageId)==null)
		{
			String pageName = page.getPageName();
			String authorName = page.getAuthorName();
			Page newPage = new Page(pageId,pageName,authorName);
			db.getPagesTable().put(pageId, newPage);
		}
		else
		{
			throw new WikiException(ExceptionConstants.EXCEPTION_PAGE_ALREADY_EXIST);
		}
	}

	public void removePage(long pageId) throws WikiException
	{
		if(db.getPagesTable().get(pageId)==null)
		{
			db.getPagesTable().remove(pageId);
		}
		else
		{
			throw new WikiException(ExceptionConstants.EXCEPTION_PAGE_ALREADY_EXIST);
		}
	}

	public void updatePage(Page page) throws WikiException
	{
		long pageId = page.getPageId();

		if(db.getPagesTable().get(pageId)==null)
		{
			throw new WikiException(ExceptionConstants.EXCEPTION_PAGE_NOT_EXIST);
		}
		else
		{
			db.getPagesTable().put(pageId,page);
		}
	}

	public void relatePageToPage(Page page1, Page page2)
	{
		long page1Id = page1.getPageId();
		long page2Id = page2.getPageId();

		if(db.getPage2PageRelations().get(page1Id)==null)
		{
			db.getPage2PageRelations().put(page1Id, new HashMap<Long, Page>());
		}
		if(db.getPage2PageRelations().get(page2Id)==null)
		{
			db.getPage2PageRelations().put(page2Id, new HashMap<Long, Page>());
		}
		db.getPage2PageRelations().get(page1Id).put(page2Id, page2);
		db.getPage2PageRelations().get(page2Id).put(page1Id, page1);
	}

	public void relatePageToPicture(Page page, Picture picture)
	{
		long pageId = page.getPageId();
		long pictureId = picture.getPictureId();

		if(db.getPage2PageRelations().get(pageId)==null)
		{
			db.getPage2PictureRelations().put(pageId, new HashMap<Long, Picture>());
		}
		if(db.getPicture2PageRelations().get(pictureId)==null)
		{
			db.getPicture2PageRelations().put(pictureId, new HashMap<Long, Page>());
		}
		db.getPage2PictureRelations().get(pageId).put(pictureId, picture);
		db.getPicture2PageRelations().get(pictureId).put(pageId, page);
	}

	public void relatePageToParagraph(Page page, Paragraph paragraph)
	{
		long pageId = page.getPageId();
		long paragraphId = paragraph.getPararaphId();

		if(db.getPage2ParagraphRelations().get(pageId)== null)
		{
			db.getPage2ParagraphRelations().put(pageId, new HashMap<Long, Paragraph>());
		}
		if(db.getParagraph2PageRelations().get(paragraphId)==null)
		{
			db.getParagraph2PageRelations().put(paragraphId, new HashMap<Long, Page>());
		}
		db.getPage2ParagraphRelations().get(pageId).put(paragraphId, paragraph);
		db.getParagraph2PageRelations().get(paragraphId).put(pageId, page);
	}

	public Map<Long,Paragraph> getRelatedParagraphs(long pageId)
	{
		Map<Long,Paragraph> map = db.getPage2ParagraphRelations().get(pageId);
		return map;
	}
	
	public Map<Long,Page> getRelatedPages(long pageId)
	{
		Map<Long,Page> map = db.getPage2PageRelations().get(pageId);
		return map;
	}
	
	public Map<Long,Picture> getRelatedPictures(long pageId)
	{
		Map<Long,Picture> map = db.getPage2PictureRelations().get(pageId);
		return map;
	}

	public void ValidatePage(Page page) throws WikiException
	{
		long pageId = page.getPageId();
		if(db.getPagesTable().get(pageId)!=null)
		{			
			throw new WikiException(ExceptionConstants.EXCEPTION_PAGE_ALREADY_EXIST);
		}
		if(page.getPageName()==null)
		{			
			throw new WikiException(ExceptionConstants.EXCEPTION_PAGE_NAME_NULL);
		}
		
		Set<Long> relatedPagesSet = page.getRelatedPagesId();
		for(Long relatedPageId : relatedPagesSet)
		{
			Page relatedPage = db.getPagesTable().get(relatedPageId);
			if(relatedPage==null)
			{
				throw new WikiException(String.format(ExceptionConstants.EXCEPTION_PAGE_RELATION_NOT_EXIST,relatedPageId));

			}
		}
	}
	
}
