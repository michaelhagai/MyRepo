package wiki.bean.interfaces;

public interface WikiBean 
{

}
