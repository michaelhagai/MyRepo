package com.wiki.exception;

public class WikiException extends Exception {

	private static final long serialVersionUID = 1830193325976727965L;
	private int errcode;

	public int getErrcode() 
	{
		return errcode;
	}

	public void setErrcode(int errcode) 
	{
		this.errcode = errcode;
	}

	public WikiException(String message, Throwable cause) 
	{
		super(message, cause);
	}

	public WikiException(String message) 
	{
		super(message);
	}

	public WikiException(String message, int errcode) 
	{
		super(message);
		this.setErrcode(errcode);
	}
}
