package com.wiki.exception;

public class ExceptionConstants 
{
	public static final String EXCEPTION_PAGE_ALREADY_EXIST="ERROR: Page already exists";
	public static final String EXCEPTION_PAGE_NAME_NULL="ERROR: Page Name cannot be null";
	public static final String EXCEPTION_PAGE_NAME_NOT_UNIQUE="ERROR: Page Name cannot be null";

	public static final String EXCEPTION_PAGE_NOT_EXIST="ERROR: Page Does not exist";
	public static final String EXCEPTION_PAGE_RELATION_NOT_EXIST="ERROR: Ralted Page Does not exist. Page cannot be related to pageId: %s";
	public static final String EXCEPTION_PAGE_NOT_EXIST_FAIL_TO_RELATE_PICTURES="ERROR: Page Does not exist. Picture cannot be related to pageId: %s";
	public static final String EXCEPTION_PAGE_NOT_EXIST_FAIL_TO_RELATE_PAGES="ERROR: Page Does not exist. Page cannot be related to pageId: %s";
	public static final String EXCEPTION_PAGE_NOT_EXIST_FAIL_TO_RELATE_PARAGRAPH="ERROR: Page Does not exist. Paragraph cannot be related to pageId: %s";
	
	public static final String EXCEPTION_PARAGRAPH_ALREADY_EXIST="ERROR: Paragraph already exists";
	public static final String EXCEPTION_PARAGRAPH_NOT_EXIST="ERROR: Paragraph Does not exist";
	
	public static final String EXCEPTION_PICTURE_ALREADY_EXIST="ERROR: Picture already exists";
	public static final String EXCEPTION_PICTURE_NOT_EXIST="ERROR: Picture Does not exist";

}
