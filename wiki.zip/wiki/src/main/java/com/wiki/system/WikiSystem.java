package com.wiki.system;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;



@SpringBootApplication
@ComponentScan(basePackages = {"com.wiki"})
@PropertySource("application.properties")
public class WikiSystem 
{
	public static void main(String[] args) 
	{
		SpringApplication.run(WikiSystem.class,args);
	}
}
