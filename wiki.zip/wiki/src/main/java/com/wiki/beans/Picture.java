package com.wiki.beans;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.wiki.interfaces.WikiBean;

//@Component
//@Scope("prototype")
public class Picture implements Serializable,WikiBean
{
	private long pictureId;
	private String filePath;
	private Double size;
	
	public Picture(){}

	
	public Picture(long pictureId, String filePath, Double size) 
	{
		this.pictureId = pictureId;
		this.filePath = filePath;
		this.size = size;
	}
	public long getPictureId() 
	{
		return pictureId;
	}
	public void setPictureId(long pictureId) 
	{
		this.pictureId = pictureId;
	}
	public String getFilePath() 
	{
		return filePath;
	}
	public void setFilePath(String filePath) 
	{
		this.filePath = filePath;
	}
	public Double getSize() 
	{
		return size;
	}
	public void setSize(Double size) 
	{
		this.size = size;
	}

	
	
}
