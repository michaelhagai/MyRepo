package com.wiki.beans;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import wiki.bean.interfaces.WikiBean;

//@Component
//@Scope("prototype")
public class Paragraph implements Serializable,WikiBean
{
	private long pararaphId;
	private int sequence;
	private String content;
	private long pageId;
	
	public Paragraph(){}
	
	public Paragraph(long pararaphId, int sequence, String content, long pageId) 
	{
		this.pararaphId = pararaphId;
		this.sequence = sequence;
		this.content = content;
		this.pageId = pageId;
	}
	public long getPararaphId() 
	{
		return pararaphId;
	}
	public void setPararaphId(long pararaphId) 
	{
		this.pararaphId = pararaphId;
	}
	public int getSequence() 
	{
		return sequence;
	}
	public void setSequence(int sequence) 
	{
		this.sequence = sequence;
	}
	public String getContent() 
	{
		return content;
	}
	public void setContent(String content) 
	{
		this.content = content;
	}
	public long getPageId() {
		return pageId;
	}
	
}
