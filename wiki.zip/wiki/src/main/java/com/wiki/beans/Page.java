package com.wiki.beans;

import java.io.Serializable;
import java.util.*;

import org.hibernate.validator.internal.util.IgnoreJava6Requirement;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import wiki.bean.interfaces.WikiBean;

import com.fasterxml.jackson.annotation.JsonIgnore;

//@Component
//@Scope("prototype")
public class Page implements Serializable,WikiBean
{
	private long pageId;
	private String pageName;
	private String authorName;
	private Date creationDate;
	private Date lastModifiedDate;
	private Map<Long,Picture> relatedPictures;
	private Map<Long,Paragraph> relatedParagraph;
	private Map<Long,Page> relatedPages;
	private Set<Long> relatedPagesId;


	public Page(){}
	
	//Constructor to create page from DB
	public Page(long pageId, String pageName, String authorName) 
	{
		this.pageId = pageId;
		this.pageName = pageName;
		this.authorName = authorName;
		this.creationDate = new Date();
		this.lastModifiedDate = creationDate;
	}
	
	public Page(long pageId, String pageName, String authorName,Date creationDate, 
			Date lastModifiedDate,
			Map<Long, Picture> relatedPictures,
			Map<Long, Paragraph> relatedParagraphs,
			Map<Long, Paragraph> relatedPages) 
	{
		this.pageId = pageId;
		this.pageName = pageName;
		this.authorName = authorName;
		this.creationDate = creationDate;
		this.lastModifiedDate = lastModifiedDate;
		this.relatedPictures = relatedPictures;
		this.relatedParagraph = relatedParagraphs;
		this.relatedParagraph = relatedPages;
		this.relatedPagesId = relatedPages.keySet();
	}
	
	public long getPageId() 
	{
		return pageId;
	}


	public void setPageId(int pageId) {
		this.pageId = pageId;
	}
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public Date getCreationDate() {
		return creationDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Map<Long, Picture> getRelatedPictures() {
		return relatedPictures;
	}

	public Map<Long, Paragraph> getRelatedParagraph() {
		return relatedParagraph;
	}

	public Map<Long, Page> getRelatedPages() {
		return relatedPages;
	}

	public void setRelatedPictures(Map<Long, Picture> relatedPictures) {
		this.relatedPictures = relatedPictures;
	}

	public void setRelatedParagraph(Map<Long, Paragraph> relatedParagraph) {
		this.relatedParagraph = relatedParagraph;
	}

	@JsonIgnore 
	public void setRelatedPages(Map<Long, Page> relatedPages) {
		this.relatedPages = relatedPages;
	}

	public Set<Long> getRelatedPagesId() {
		return relatedPagesId;
	}

	public void setRelatedPagesId(Set<Long> relatedPagesId) {
		this.relatedPagesId = relatedPagesId;
	}

}
