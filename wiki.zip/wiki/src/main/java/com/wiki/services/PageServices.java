package com.wiki.services;

import java.beans.Transient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.wiki.beans.*;
import com.wiki.dao.*;
import com.wiki.exception.WikiException;

/**
 * This Class represents the Page Services - I focused on Add/Get Page. Modify Page also can be added here and in Picture/Paragraph services.
 * I'm adding as an input the Page object and his relations with IDs although Using a real DB I would create the ID incrementally in the table itself.
 * 
 * @author MHAGAI
 *
 */


@RestController
@Component
@EnableAutoConfiguration
@RequestMapping("rest/page")
public class PageServices 
{
	@Autowired
	PageDao pageDao;
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> addPage(@RequestBody Page page) throws WikiException
	{	
		pageDao.addNewPage(page);
		return new ResponseEntity<String>(HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/get/{pageId}")
	@ResponseBody
	public ResponseEntity<Page> getPage(@PathVariable Long pageId) throws WikiException
	{
		Page page = pageDao.getPage(pageId);
		return new ResponseEntity<Page>(page, HttpStatus.CREATED);
	}
	        
	@RequestMapping("*")
	@ResponseBody
	public ResponseEntity<String> fallbackMethod(){
		return new ResponseEntity<String>("Service Not Found",HttpStatus.NOT_FOUND);
	}
}
