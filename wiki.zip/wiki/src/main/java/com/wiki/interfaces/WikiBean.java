package com.wiki.interfaces;

public interface WikiBean 
{

}
