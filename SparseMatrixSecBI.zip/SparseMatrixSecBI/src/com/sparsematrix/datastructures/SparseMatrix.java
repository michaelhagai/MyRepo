package com.sparsematrix.datastructures;

import java.util.*;
import com.sparsematrix.exceptions.SparseMatrixException;

/**
 * 
 * @author MHAGAI
 *	
 *	This Class represents a Sparse-Matrix Data Structure.
 *	
 *	1. basic add/remove methods
 *	2. Algorithm to check if the Spares-Matrix is a unique case of an N-Grade sparse matrix 
 *	3. 2 inner classes that represents the cell coordinates and a node (cell coordinates and a given value)
 *
 */
public class SparseMatrix 
{
	private int matrixDimension;
	private int matrixMaxNumberOfValidNodes;
	private int matrixNumberOfNodes;
	private Map<SparseMatrixNodeCoordinates , SparseMatrixNode > nodesMap;
	private List<SparseMatrixNodeCoordinates> nodesCoordinateList;

	public SparseMatrix(int matrixDimension) throws SparseMatrixException
	{
		if(matrixDimension <= 0)
		{
			throw new SparseMatrixException("Dimension value must be positive");
		}

		this.matrixDimension = matrixDimension;
		matrixMaxNumberOfValidNodes = (int) (((Math.pow(matrixDimension,2))/2)-1);
		matrixNumberOfNodes = 0;
		nodesMap = new HashMap<SparseMatrixNodeCoordinates, SparseMatrix.SparseMatrixNode>();
		nodesCoordinateList = new ArrayList<SparseMatrix.SparseMatrixNodeCoordinates>();
	}

	public void addCell(int xCoordinate, int yCoordinate,int value) throws SparseMatrixException
	{

		if(matrixNumberOfNodes == matrixMaxNumberOfValidNodes)
		{
			throw new SparseMatrixException(String.format("ERROR: Additional cells cannot be added. maxNumberOfValidNodes = %s , currentNumberOfNodes = %s ", matrixMaxNumberOfValidNodes , matrixNumberOfNodes));
		}

		SparseMatrixNode node = new SparseMatrixNode(xCoordinate, yCoordinate, value);
		validateNode(node);

		boolean isValueNotZero = node.getValue() != 0 ;

		if(isValueNotZero)
		{
			if(!nodesMap.containsKey(node.getCoordinates()))
			{
				nodesCoordinateList.add(node.getCoordinates());
			}

			nodesMap.put(node.getCoordinates() , node);

			matrixNumberOfNodes = nodesMap.size();
		}
	}

	public void removeCell(int xCoordinate, int yCoordinate) throws SparseMatrixException
	{
		SparseMatrixNodeCoordinates nodeCoordinates = new SparseMatrixNodeCoordinates(xCoordinate, yCoordinate);

		if(nodesMap.keySet().contains(nodeCoordinates))
		{
			nodesMap.remove(nodeCoordinates);
			matrixNumberOfNodes = nodesMap.size()+1;
		}		
	}

	private void validateNode(SparseMatrixNode node) throws SparseMatrixException 
	{
		boolean isXOutOfBounds = node.getCoordinates().getX() < 1 || node.getCoordinates().getX() > matrixDimension;
		boolean isYOutOfBounds = node.getCoordinates().getY() < 1 || node.getCoordinates().getY() > matrixDimension;
		if(isXOutOfBounds || isYOutOfBounds)
		{
			throw new SparseMatrixException(String.format("ERROR: Node's coordinates must be between 1 - %s", matrixDimension));
		}
	}

	public int getMatrixDimension() 
	{
		return matrixDimension;
	}

	public double getMaxNumberOfValidNodes() 
	{
		return matrixMaxNumberOfValidNodes;
	}

	public double getCurrentNumberOfNodes() 
	{
		return matrixNumberOfNodes;
	}

	/**
	 * Check if the SparseMatrix is N-Grade SparseMatrix.
	 * return biggest valid N dimension if true, else return -1;
	 * 
	 * Algorithm Steps:
	 * 1. Sort Matrix Nodes coordinates.
	 * 2. Find a cluster side size and calculate the total number of cells that a cluster should have. (Based on the 1st given side)
	 * 3. Define cluster ranges.
	 * 4. If number of Cells inside the range is equal to the calculated number of cells: 
	 * 		a. It's a cluster. 
	 * 		b. Update the next cluster required data based on the next cell that.
	 * 5. Back to #4
	 * 
	 * ** In between the following steps there are validations that can STOP the algorithm and define the Sparse Matrix as non N-Grade Sparse matrix 
	 * 
	 */
	public int isNGradeSparseMatrix()
	{
		int currentNumberOfCells = 0;

		if(matrixNumberOfNodes < 1)
		{
			return -1;
		}

		Collections.sort(nodesCoordinateList);
		ClusterData clusterData = initilizeClusterData();
		calculateClusterDimensionAndRequiredCellsNumber(clusterData);

		for (int i = 0 ; i < nodesCoordinateList.size()- clusterData.getClusterNumberOfCells() -1; i++) 
		{
			for (int j = 0; j < clusterData.getClusterNumberOfCells(); j++) 
			{
				if(!currentCellInClusterRangeValidation(clusterData, i, j))
				{
					return -1;
				}

				currentNumberOfCells++;

				if(allCellsInClusterRangeValidation(currentNumberOfCells, clusterData))
				{
					if(nextClusterCellAttachedToCurrentClusterValidation(clusterData, i, j))
					{
						return -1;
					}

					SparseMatrixNodeCoordinates nextXY  = nodesCoordinateList.get(j+i+1);
					updateNextClusterRequiredData(clusterData, nextXY);
				}
			}

			if(!allCellsInClusterRangeValidation(currentNumberOfCells, clusterData))
			{
				return -1;
			}	

			i = i+ clusterData.getClusterNumberOfCells() -1;
			currentNumberOfCells = 0;
		}	
		return returnBiggestClusterDimensionForNGradeSparseMatrix();
	}

	private int returnBiggestClusterDimensionForNGradeSparseMatrix() 
	{
		int lo = 0;
		int hi = matrixDimension;
		Math.round(lo + (hi - lo) / 2);
		int maxNumberOfValidFilledCells = (int) (Math.round(Math.pow(matrixDimension,2)/2)-1);
		return (int) Math.sqrt((maxNumberOfValidFilledCells));
	}

	private boolean currentCellInClusterRangeValidation(ClusterData clusterData, int i, int j) 
	{
		SparseMatrixNodeCoordinates currentXY  = nodesCoordinateList.get(j+i);
		boolean xCoordinateInRange =  currentXY.getX() >= clusterData.getClusterXMinValue() && currentXY.getX() <= clusterData.getClusterXMaxValue();
		boolean yCoordinateInRange =  currentXY.getY() >= clusterData.getClusterYMinValue() && currentXY.getY() <= clusterData.getClusterYMaxValue();

		if(!(xCoordinateInRange && yCoordinateInRange))
		{
			return false; //Not Cluster
		}
		return true;
	}

	private boolean nextClusterCellAttachedToCurrentClusterValidation(ClusterData clusterData, int i, int j) 
	{
		SparseMatrixNodeCoordinates nextXY  = nodesCoordinateList.get(j+i+1);

		boolean nextXCoordinateInRange =  nextXY.getX() >= clusterData.getClusterXMinValue() && nextXY.getX() <= clusterData.getClusterXMaxValue();
		boolean nextYCoordinateInRange =  nextXY.getY() >= clusterData.getClusterYMinValue() && nextXY.getY() <= clusterData.getClusterYMaxValue();

		boolean nextXCoordinateCloseToRange =  nextYCoordinateInRange && (nextXY.getX() == clusterData.getClusterXMinValue() -1 || nextXY.getX() == clusterData.getClusterXMaxValue() +1);
		boolean nextYCoordinateCloseToRange =  nextXCoordinateInRange && (nextXY.getY() == clusterData.getClusterYMinValue() -1 || nextXY.getY() == clusterData.getClusterYMaxValue()+1);

		if(nextXCoordinateCloseToRange || nextYCoordinateCloseToRange)
		{
			return true;//Not Cluster
		}
		return false;
	}

	private boolean allCellsInClusterRangeValidation(int currentNumberOfCells,ClusterData clusterData) 
	{
		if(!(currentNumberOfCells == clusterData.getClusterNumberOfCells()))
		{
			return false; 
		}
		return true;
	}

	private ClusterData initilizeClusterData() 
	{
		ClusterData clusterData = new ClusterData();

		clusterData.setClusterDimentionSize(1);
		clusterData.setClusterNumberOfCells(1);
		clusterData.setClusterXMinValue(nodesCoordinateList.get(0).getX());
		clusterData.setClusterXMaxValue(nodesCoordinateList.get(0).getX());
		clusterData.setClusterYMinValue(nodesCoordinateList.get(0).getY());
		clusterData.setClusterYMaxValue(nodesCoordinateList.get(0).getY());
		return clusterData;
	}

	private void updateNextClusterRequiredData(ClusterData clusterData, SparseMatrixNodeCoordinates nextXY) 
	{
		clusterData.setClusterXMinValue(nextXY.getX());
		clusterData.setClusterXMaxValue(clusterData.getClusterXMinValue() + clusterData.getClusterDimentionSize() - 1);
		clusterData.setClusterYMinValue(nextXY.getY());
		clusterData.setClusterYMaxValue(clusterData.getClusterYMinValue() + clusterData.getClusterDimentionSize() - 1);
	}

	private void calculateClusterDimensionAndRequiredCellsNumber(ClusterData clusterData) 
	{
		for (int i = 1 ; i < nodesCoordinateList.size(); i++) 
		{			
			SparseMatrixNodeCoordinates currentXY  = nodesCoordinateList.get(i);

			if(currentXY.getX() == clusterData.getClusterXMinValue()&& currentXY.getY() == clusterData.getClusterYMaxValue() + 1)
			{
				clusterData.setClusterYMaxValue(currentXY.getY());
				clusterData.setClusterXMaxValue(clusterData.getClusterXMaxValue()+1);
				clusterData.setClusterDimentionSize(clusterData.getClusterDimentionSize()+1);
			}
			else if(clusterData.getClusterDimentionSize() > 1 && clusterData.getClusterNumberOfCells() == 1)
			{
				clusterData.setClusterNumberOfCells((int) Math.pow(clusterData.getClusterDimentionSize(), 2));
				break;
			}
		}
	}

	@Override
	public String toString() 
	{
		return "SparseMatrix [matrixDimension=" + matrixDimension
				+ ", maxNumberOfValidNodes=" + matrixMaxNumberOfValidNodes
				+ ", currentNumberOfNodes=" + matrixNumberOfNodes
				+ ", nodesSet=" + nodesMap + "]";
	}

	/**
	 *	Inner class that represents a node (cell) inside the matrix
	 *	@Param SparseMatrixNodeCoordinates Coordinates - cell location in the matrix
	 *	@Param int Value - cell value in the matrix
	 */
	private class SparseMatrixNode
	{
		private SparseMatrixNodeCoordinates coordinates;
		private	int value;

		SparseMatrixNode(int xCoordinate, int yCoordinate,int value) 
		{
			coordinates = new SparseMatrixNodeCoordinates(xCoordinate, yCoordinate);
			this.value = value;
		}	

		public SparseMatrixNodeCoordinates getCoordinates() 
		{
			return coordinates;
		}

		public int getValue() 
		{
			return value;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result
					+ ((coordinates == null) ? 0 : coordinates.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			SparseMatrixNode other = (SparseMatrixNode) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (coordinates == null) {
				if (other.coordinates != null)
					return false;
			} else if (!coordinates.equals(other.coordinates))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "SparseMatrixNode [coordinates=" + coordinates.x +" , " + coordinates.y + ", value="+ value + "]";
		}

		private SparseMatrix getOuterType() {
			return SparseMatrix.this;
		}
	}


	/**
	 *	Inner class that represents the node Coordinates
	 *	@Param x - horizontal coordinate
	 *	@Param y - vertical coordinate  
	 */
	private class SparseMatrixNodeCoordinates implements Comparable<SparseMatrixNodeCoordinates>
	{
		private int x;
		private int y;

		private SparseMatrixNodeCoordinates(int x, int y) 
		{
			this.x = x;
			this.y = y;
		}

		public int getX() 
		{
			return x;
		}

		public int getY() 
		{
			return y;
		}

		@Override
		public int compareTo(SparseMatrixNodeCoordinates other) 
		{
			if(this.x > other.x)
			{
				return 1;
			}
			else if(this.x == other.x && this.y > other.y)
			{
				return 1;
			}
			else if(this.x == other.x && this.y == other.y)
			{
				return 0;
			}
			else
			{
				return -1;
			}
		}

		@Override
		public int hashCode() 
		{
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + x;
			result = prime * result + y;
			return result;
		}

		@Override
		public boolean equals(Object obj) 
		{
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			SparseMatrixNodeCoordinates other = (SparseMatrixNodeCoordinates) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (x != other.x)
				return false;
			if (y != other.y)
				return false;
			return true;
		}

		private SparseMatrix getOuterType() {
			return SparseMatrix.this;
		}

		@Override
		public String toString() {
			return "SparseMatrixNodeCoordinates [x=" + x + ", y=" + y + "]";
		}
	}

}
