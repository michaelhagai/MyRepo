package com.sparsematrix.datastructures;

public class ClusterData 
{
	int clusterDimentionSize;
	int clusterNumberOfCells;
	int clusterXMinValue;
	int clusterXMaxValue;
	int clusterYMinValue;
	int clusterYMaxValue;
	
	public ClusterData(){}

	public int getClusterDimentionSize() {
		return clusterDimentionSize;
	}

	public void setClusterDimentionSize(int clusterDimentionSize) {
		this.clusterDimentionSize = clusterDimentionSize;
	}

	public int getClusterNumberOfCells() {
		return clusterNumberOfCells;
	}

	public void setClusterNumberOfCells(int clusterNumberOfCells) {
		this.clusterNumberOfCells = clusterNumberOfCells;
	}

	public int getClusterXMinValue() {
		return clusterXMinValue;
	}

	public void setClusterXMinValue(int clusterXMinValue) {
		this.clusterXMinValue = clusterXMinValue;
	}

	public int getClusterXMaxValue() {
		return clusterXMaxValue;
	}

	public void setClusterXMaxValue(int clusterXMaxValue) {
		this.clusterXMaxValue = clusterXMaxValue;
	}

	public int getClusterYMinValue() {
		return clusterYMinValue;
	}

	public void setClusterYMinValue(int clusterYMinValue) {
		this.clusterYMinValue = clusterYMinValue;
	}

	public int getClusterYMaxValue() {
		return clusterYMaxValue;
	}

	public void setClusterYMaxValue(int clusterYMaxValue) {
		this.clusterYMaxValue = clusterYMaxValue;
	}
	
}
