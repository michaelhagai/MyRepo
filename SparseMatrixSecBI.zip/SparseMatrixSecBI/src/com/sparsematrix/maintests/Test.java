package com.sparsematrix.maintests;

import com.sparsematrix.datastructures.SparseMatrix;
import com.sparsematrix.exceptions.SparseMatrixException;

public class Test 
{
	public static void main(String[] args) throws SparseMatrixException 
	{	
		test1AddRemoveMethods();		
		test2ISNGradeMatrix();
		test3ISNotNGradeMatrix();
		test4ISNotNGradeMatrix();
		test5ISNGradeMatrix();
		test6ISNotNGradeMatrix();
		test7ISNGradeMatrix();
	}

	private static void test1AddRemoveMethods() throws SparseMatrixException 
	{
		System.out.println("");
		System.out.println("");

		SparseMatrix sm = new SparseMatrix(6);
		sm.addCell(1, 6, 3);
		sm.addCell(2, 5, 0);
		System.out.println("****************************TEST #1****************************************************");
		System.out.println("Test Add and Remove methods");
		System.out.println("---------------------------------------------------------------------------------");
		System.out.println(String.format("test1AddRemoveMethods Add Result: : %s",sm));
		sm.addCell(2, 5, 8);
		System.out.println(String.format("test1AddRemoveMethods Add Result: : %s",sm));
		sm.removeCell(1, 6);
		System.out.println(String.format("test1AddRemoveMethods Remove Result: : %s",sm));
		System.out.println("***************************************************************************************");		
		System.out.println("");
	}

	private static void test2ISNGradeMatrix() throws SparseMatrixException 
	{
		SparseMatrix ngMatrix = new SparseMatrix(8);
		ngMatrix.addCell(2, 7, 3);
		ngMatrix.addCell(2, 8, 8);
		ngMatrix.addCell(3, 7, 99);
		ngMatrix.addCell(3, 8, 5);
		
		ngMatrix.addCell(4, 4, 2);
		ngMatrix.addCell(4, 5, 7);
		ngMatrix.addCell(5, 4, 9);
		ngMatrix.addCell(5, 5, 14);

		ngMatrix.addCell(7, 3, 12);
		ngMatrix.addCell(7, 4, 1);
		ngMatrix.addCell(8, 3, 55);
		ngMatrix.addCell(8, 4, 6);
		
		System.out.println("****************************TEST #2****************************************************");
		System.out.println("Is N-Grade Sparse Matrix: All added cells have values <> 0, cluster dimension = 2");
		System.out.println("---------------------------------------------------------------------------------");
		System.out.println(String.format("Result: Biggest N for ngMatrix is: %s",ngMatrix.isNGradeSparseMatrix()));
		System.out.println("***************************************************************************************");
		System.out.println("");
	}
	
	private static void test3ISNotNGradeMatrix() throws SparseMatrixException 
	{
		SparseMatrix ngMatrix = new SparseMatrix(20);
		ngMatrix.addCell(2, 7, 3);
		
		ngMatrix.addCell(4, 4, 2);
		ngMatrix.addCell(4, 5, 7);
		ngMatrix.addCell(5, 4, 9);
		ngMatrix.addCell(5, 5, 14);
		ngMatrix.addCell(4, 6, 14);

		ngMatrix.addCell(7, 3, 12);
		ngMatrix.addCell(7, 4, 1);
		ngMatrix.addCell(8, 3, 55);
		ngMatrix.addCell(8, 4, 6);
		
		System.out.println("*****************************TEST #3***************************************************");
		System.out.println("Is Not N-Grade Sparse Matrix: All added cells have values <> 0, same dimention , but 1 cluster have missing cell - Value is Zero");
		System.out.println("----------------------------------------------------------------------------------------------------------------");
		System.out.println(String.format("Result is: %s",ngMatrix.isNGradeSparseMatrix()));
		System.out.println("***************************************************************************************");
	}
	
	private static void test4ISNotNGradeMatrix() throws SparseMatrixException 
	{
		SparseMatrix ngMatrix = new SparseMatrix(20);
		ngMatrix.addCell(2, 7, 3);
		ngMatrix.addCell(2, 8, 8);
		ngMatrix.addCell(3, 7, 0);
		ngMatrix.addCell(3, 8, 5);
		
		ngMatrix.addCell(4, 4, 2);
		ngMatrix.addCell(4, 5, 7);
		ngMatrix.addCell(5, 4, 9);
		ngMatrix.addCell(5, 5, 14);

		ngMatrix.addCell(7, 3, 12);
		ngMatrix.addCell(7, 4, 1);
		ngMatrix.addCell(8, 3, 55);
		ngMatrix.addCell(8, 4, 6);
		
		System.out.println("*****************************TEST #4***************************************************");
		System.out.println("Is Not N-Grade Sparse Matrix: All added cells have values <> 0, but not all are clusters with the same dimention");
		System.out.println("----------------------------------------------------------------------------------------------------------------");
		System.out.println(String.format("Result is: %s",ngMatrix.isNGradeSparseMatrix()));
		System.out.println("***************************************************************************************");
	}
	
	private static void test5ISNGradeMatrix() throws SparseMatrixException 
	{
		SparseMatrix ngMatrix = new SparseMatrix(20);
		ngMatrix.addCell(2, 7, 3);
		
		ngMatrix.addCell(4, 4, 2);

		ngMatrix.addCell(7, 3, 12);
		
		System.out.println("*****************************TEST #5***************************************************");
		System.out.println("Is N-Grade Sparse Matrix: All added cells have values <> 0, N Grade = 1");
		System.out.println("----------------------------------------------------------------------------------------------------------------");
		System.out.println(String.format("Result is: %s",ngMatrix.isNGradeSparseMatrix()));
		System.out.println("***************************************************************************************");
	}
	
	private static void test6ISNotNGradeMatrix() throws SparseMatrixException 
	{
		SparseMatrix ngMatrix = new SparseMatrix(20);

		
		System.out.println("*****************************TEST #6***************************************************");
		System.out.println("Is NOT N-Grade Sparse Matrix: No added cells");
		System.out.println("----------------------------------------------------------------------------------------------------------------");
		System.out.println(String.format("Result is: %s",ngMatrix.isNGradeSparseMatrix()));
		System.out.println("***************************************************************************************");
	}
		
	private static void test7ISNGradeMatrix() throws SparseMatrixException 
	{
		SparseMatrix ngMatrix = new SparseMatrix(50);
		ngMatrix.addCell(2, 7, 3);
		ngMatrix.addCell(2, 8, 8);
		ngMatrix.addCell(2, 9, 8);
		ngMatrix.addCell(3, 7, 99);
		ngMatrix.addCell(3, 8, 5);
		ngMatrix.addCell(3, 9, 5);
		ngMatrix.addCell(1, 7, 99);
		ngMatrix.addCell(1, 8, 5);
		ngMatrix.addCell(1, 9, 5);
		
		ngMatrix.addCell(4, 4, 2);
		ngMatrix.addCell(4, 5, 7);
		ngMatrix.addCell(4, 6, 7);
		ngMatrix.addCell(5, 4, 9);
		ngMatrix.addCell(5, 5, 14);
		ngMatrix.addCell(5, 6, 14);
		ngMatrix.addCell(6, 4, 9);
		ngMatrix.addCell(6, 5, 14);
		ngMatrix.addCell(6, 6, 14);
		
		
		ngMatrix.addCell(10, 3, 12);
		ngMatrix.addCell(10, 1,3);
		ngMatrix.addCell(10, 3, 55);
		ngMatrix.addCell(11, 3, 12);
		ngMatrix.addCell(11, 1,3);
		ngMatrix.addCell(11, 3, 55);
		ngMatrix.addCell(12, 3, 12);
		ngMatrix.addCell(12, 1,3);
		ngMatrix.addCell(12, 3, 55);
		
		System.out.println("****************************TEST #7****************************************************");
		System.out.println("Is N-Grade Sparse Matrix: All added cells have values <> 0, cluster dimension = 3");
		System.out.println("---------------------------------------------------------------------------------");
		System.out.println(String.format("Result: Biggest N for ngMatrix is: %s",ngMatrix.isNGradeSparseMatrix()));
		System.out.println("***************************************************************************************");
		System.out.println("");
	}
	
	
}
