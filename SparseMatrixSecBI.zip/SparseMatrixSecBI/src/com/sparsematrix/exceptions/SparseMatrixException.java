package com.sparsematrix.exceptions;

public class SparseMatrixException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int errcode;

	public int getErrcode() 
	{
		return errcode;
	}

	public void setErrcode(int errcode) 
	{
		this.errcode = errcode;
	}

	public SparseMatrixException(String message, Throwable cause) 
	{
		super(message, cause);
	}

	public SparseMatrixException(String message) 
	{
		super(message);
	}

	public SparseMatrixException(String message, int errcode) 
	{
		super(message);
		this.setErrcode(errcode);
	}
}